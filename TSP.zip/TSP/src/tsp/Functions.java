/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tsp;

/**
 *
 * @author umics
 */
public class Functions {
    
    public static int distance(int x1,int y1,int x2,int y2){
        
           int dx = 0;
           int dy = 0;
        
        if(x1>x2){
           dx = x1 - x2;
            }
        if(x2>x1){
            dx = x2 - x1;
            }
        
        if(y1>y2){
            dy = y1 - y2;
        }
        if(y2>y1){
            dy = y2 - y1;
           }
        
        int dis = (int)(Math.sqrt((double)(dx * dx + dy * dy)));
        
        return dis;
        
    }
        
    
    public static void tauschen(int a, int b){
        
        int tempxa = Saves.TempDatenX[a];
        int tempxb = Saves.TempDatenX[b];
        
        int tempya = Saves.TempDatenY[a];
        int tempyb = Saves.TempDatenY[b];
        
        Saves.TempDatenX[tempxa] = tempxb;
        Saves.TempDatenX[tempxb] = tempxa;
        
        Saves.TempDatenY[tempya] = tempyb;
        Saves.TempDatenY[tempyb] = tempya;
        
        return;
        
                
    }
    
        
    
    
    }

    

