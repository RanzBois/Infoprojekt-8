/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tsp;

/**
 *
 * @author umics
 */
public class Saves {
    public static int [] AnzahlPunkte = new int [1];
    //globales Array fuer die Anzahl der Punkte
    
    
    public static int [] DatenX  = new int[Saves.AnzahlPunkte[0]];
    
    public static int [] DatenY =  new int [Saves.AnzahlPunkte[0]];
    
    
    
    
    public static int [] TempDatenX = new int [Saves.AnzahlPunkte[0]];
            
    public static int [] TempDatenY = new int [Saves.AnzahlPunkte[0]];
            
    public static int [] TempDis1 = new int [Saves.AnzahlPunkte[0]];   
        
    public static int [] TempDis2 = new int [Saves.AnzahlPunkte[0]];
    
    
    
    
    
    public static int [] Distance = new int[Saves.AnzahlPunkte[0]];
    
    
    
    
    public static boolean Start = false;
    
    //public static int [] Distance = new int[Saves.AnzahlPunkte[0]-1];
    
    
    
}
